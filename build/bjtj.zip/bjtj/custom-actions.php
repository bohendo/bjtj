<?php

update_option('bjtj_debug', '');

?>
