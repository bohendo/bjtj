<?php

// https://thomasclowes.com/verifying-an-ethereum-signature-on-the-server-php/
// https://thomasclowes.com/verifying-an-ethereum-signature-on-the-server-php-2/

include ABSPATH.'wp-content/plugins/bjtj/CryptoCurrency.php';

$agreement = 'I understand and agree that
this game is an elaborate tip jar.
Although I expect to be able to
exchange my chips for Ether,
I am at peace knowing that the
site owner may, at any time and
for any reason, be unable or
unwilling to refund my chips.
';

function bjtj_hash_message($msg) {

  // hash1 = 183,36,114 aka b72472
  // hash2 = 234,13,8 aka ea0d08

  $out = hash('sha3-256', 
    hash('sha3-256', 'string Agreement').hash('sha3-256', $msg)
  );

  // hashing ''
  // JS  gives 197,210,70 aka c5d246  (keccak)
  // PHP gives 167,255,198 aka a7ffc6 (sha3)
  echo hash('sha3-256', '');

  $out = hash('sha3-256', $msg);

  return $out;

}

function bjtj_auth($id, $ag) {

  global $agreement;

  // get message, convert it to a buffer, and hash it
  //   like eth-sig-utils::typedSignatureHash

  // should be: 0xe2e5aefbc7266055...
  $agreement_hash = bjtj_hash_message($agreement);
  if (substr($agreement_hash, 0, 6) !== "e2e5ae") {
    echo $agreement_hash;
    return false;
  }

  // get signed message & hash it
  $hash = '0x123abc';

  // convert $ag to array of 64 decimal numbers
  // first 32 = r, second 32 = s, last = v
  $R = '0xabc123';
  $S = '0xabc123';
  $v = 28;
  $pubKey = recoverPublicKey_HEX($v-27, $R, $S, $hash);
  // convert pubKey to eth address

  return true;
}

?>
